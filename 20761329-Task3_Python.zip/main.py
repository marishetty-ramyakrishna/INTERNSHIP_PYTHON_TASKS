
# Task 3: Main program to test all 15 solutions

from solutions import (
    word_frequency,
    character_frequency,
    first_non_repeating,
    are_anagrams,
    first_repeating_char,
    move_zeros,
    second_highest,
    remove_duplicates,
    find_missing,
    find_pair,
    closest_to_zero,
    find_common,
    rotate_right,
    max_consecutive_sum,
    find_all_pairs
)

print("Q1. Word frequency:")
print(word_frequency("python is easy and python is powerful"))

print("\nQ2. Character frequency:")
print(character_frequency("banana"))

print("\nQ3. First non-repeating character:")
print(first_non_repeating("swiss"))

print("\nQ4. Check anagrams:")
print(are_anagrams("listen", "silent"))

print("\nQ5. First repeating character:")
print(first_repeating_char("programming"))

print("\nQ6. Move zeros to the end:")
print(move_zeros([0, 3, 0, 1, 2, 0, 4]))

print("\nQ7. Second-highest distinct number:")
print(second_highest([10, 20, 40, 30, 40, 20]))

print("\nQ8. Remove duplicates:")
print(remove_duplicates([4, 2, 4, 5, 2, 7, 5]))

print("\nQ9. Find the missing number:")
print(find_missing([1, 2, 4, 5, 6], 6))

print("\nQ10. Find a pair with the target sum:")
print(find_pair([2, 7, 11, 15], 9))

print("\nQ11. Number closest to zero:")
print(closest_to_zero([-8, -3, 2, 5, -2]))

print("\nQ12. Common elements:")
print(find_common([1, 2, 3, 4, 5], [3, 4, 5, 6, 7]))

print("\nQ13. Rotate list to the right:")
print(rotate_right([1, 2, 3, 4, 5], 2))

print("\nQ14. Maximum sum of consecutive elements:")
print(max_consecutive_sum([4, 7, 2, 9, 5]))

print("\nQ15. All unique pairs with target sum:")
print(find_all_pairs([2, 4, 3, 5, 7, 8, 1], 9))
