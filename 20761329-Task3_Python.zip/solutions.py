
# Task 3: Python Coding and Problem-Solving
# Solutions for all 15 questions


# Q1. Frequency of each word
def word_frequency(sentence):
    frequency = {}
    for word in sentence.split():
        frequency[word] = frequency.get(word, 0) + 1
    return frequency


# Q2. Frequency of each character
def character_frequency(word):
    frequency = {}
    for char in word:
        frequency[char] = frequency.get(char, 0) + 1
    return frequency


# Q3. First non-repeating character
def first_non_repeating(word):
    for char in word:
        if word.count(char) == 1:
            return char
    return None


# Q4. Check whether two strings are anagrams
def are_anagrams(s1, s2):
    return sorted(s1) == sorted(s2)


# Q5. First repeating character
def first_repeating_char(word):
    seen = set()
    for char in word:
        if char in seen:
            return char
        seen.add(char)
    return None


# Q6. Move zeros to the end
def move_zeros(nums):
    non_zeros = [num for num in nums if num != 0]
    zeros = [num for num in nums if num == 0]
    return non_zeros + zeros


# Q7. Find the second-highest distinct number
def second_highest(nums):
    unique_nums = sorted(set(nums), reverse=True)
    if len(unique_nums) < 2:
        return None
    return unique_nums[1]


# Q8. Remove duplicates while preserving order
def remove_duplicates(nums):
    unique_nums = []
    for num in nums:
        if num not in unique_nums:
            unique_nums.append(num)
    return unique_nums


# Q9. Find the missing number from 1 to N
def find_missing(nums, N):
    expected_sum = N * (N + 1) // 2
    return expected_sum - sum(nums)


# Q10. Find a pair whose sum equals the target
# Select the pair whose second element appears earliest.
def find_pair(nums, target):
    for j in range(len(nums)):
        for i in range(j):
            if nums[i] + nums[j] == target:
                return [nums[i], nums[j]]
    return []


# Q11. Find the number closest to zero
# If tied, choose the positive number.
def closest_to_zero(nums):
    if not nums:
        return None

    closest = nums[0]

    for num in nums:
        if abs(num) < abs(closest):
            closest = num
        elif abs(num) == abs(closest) and num > closest:
            closest = num

    return closest


# Q12. Find common elements between two lists
# Preserve first-list order and include each value once.
def find_common(list1, list2):
    common = []
    for num in list1:
        if num in list2 and num not in common:
            common.append(num)
    return common


# Q13. Rotate a list to the right by K positions
def rotate_right(nums, k):
    if len(nums) == 0:
        return []
    k = k % len(nums)
    if k == 0:
        return nums[:]
    return nums[-k:] + nums[:-k]


# Q14. Maximum sum of two consecutive elements
def max_consecutive_sum(nums):
    if len(nums) < 2:
        return None

    max_sum = nums[0] + nums[1]

    for i in range(1, len(nums) - 1):
        current_sum = nums[i] + nums[i + 1]

        if current_sum > max_sum:
            max_sum = current_sum

    return max_sum


# Q15. Find all unique pairs that sum to the target
def find_all_pairs(nums, target):
    pairs = []
    for i in range(len(nums)):
        for j in range(i + 1, len(nums)):
            if nums[i] + nums[j] == target:
                pair = sorted([nums[i], nums[j]])
                if pair not in pairs:
                    pairs.append(pair)
    pairs.sort()
    return pairs
