# Problem 15: Word Order
# HackerRank: https://www.hackerrank.com/challenges/word-order/problem

n = int(input())
words = {}
order = []

for i in range(n):
    word = input()

    if word not in words:
        words[word] = 1
        order.append(word)
    else:
        words[word] += 1

print(len(words))
print(*[words[word] for word in order])